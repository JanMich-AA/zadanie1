

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

interface Polecenie {
    void wykonaj();
}

class Zamowienie {
    private String danie;
    private boolean przygotowane = false;
    private boolean dostarczone = false;

    public Zamowienie(String danie) {
        this.danie = danie;
    }

    public String getDanie() {
        return danie;
    }

    public boolean isPrzygotowane() {
        return przygotowane;
    }

    public void setPrzygotowane(boolean przygotowane) {
        this.przygotowane = przygotowane;
    }

    public boolean isDostarczone() {
        return dostarczone;
    }

    public void setDostarczone(boolean dostarczone) {
        this.dostarczone = dostarczone;
    }
}

class PrzyjmijZamowienie implements Polecenie {
    private Zamowienie zamowienie;

    public PrzyjmijZamowienie(Zamowienie zamowienie) {
        this.zamowienie = zamowienie;
    }

    @Override
    public void wykonaj() {
        System.out.println("Przyjęto zamówienie na: " + zamowienie.getDanie());
    }
}

class PrzygotujPosilek implements Polecenie {
    private Zamowienie zamowienie;

    public PrzygotujPosilek(Zamowienie zamowienie) {
        this.zamowienie = zamowienie;
    }

    @Override
    public void wykonaj() {
        System.out.println("Przygotowano posiłek: " + zamowienie.getDanie());
        zamowienie.setPrzygotowane(true);
    }
}

class DostarczPosilek implements Polecenie {
    private Zamowienie zamowienie;

    public DostarczPosilek(Zamowienie zamowienie) {
        this.zamowienie = zamowienie;
    }

    @Override
    public void wykonaj() {
        if (zamowienie.isPrzygotowane()) {
            System.out.println("Dostarczono posiłek: " + zamowienie.getDanie());
            zamowienie.setDostarczone(true);
        } else {
            System.out.println("Nie można dostarczyć posiłku, ponieważ nie został przygotowany.");
        }
    }
}

class Kelner {
    private List<Polecenie> kolejkaPolecen = new ArrayList<>();

    public void dodajPolecenie(Polecenie polecenie) {
        kolejkaPolecen.add(polecenie);
    }

    public void wykonajPolecenia() {
        for (Polecenie polecenie : kolejkaPolecen) {
            polecenie.wykonaj();
        }
        kolejkaPolecen.clear();
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj nazwę dania do zamówienia: ");
        String nazwaDania = scanner.nextLine();

        Zamowienie zamowienie = new Zamowienie(nazwaDania);

        Polecenie przyjmijZamowienie = new PrzyjmijZamowienie(zamowienie);
        Polecenie przygotujPosilek = new PrzygotujPosilek(zamowienie);
        Polecenie dostarczPosilek = new DostarczPosilek(zamowienie);

        Kelner kelner = new Kelner();
        kelner.dodajPolecenie(przyjmijZamowienie);
        kelner.dodajPolecenie(przygotujPosilek);
        kelner.dodajPolecenie(dostarczPosilek);

        kelner.wykonajPolecenia();
    }
}
         

